﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prj_wfrm_centreCall_tickets
{
    public partial class frmNbTicketsParClient : Form
    {
        public frmNbTicketsParClient()
        {
            InitializeComponent();
        }

        private void frmNbTicketsParClient_Load(object sender, EventArgs e)
        {
            if (tab.nbClients == 0)
            {
                MessageBox.Show("Aucun client", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                //parcours du tableau des centres d'appel
                for (int i = 0; i < tab.nbClients; i++)
                {
                    ListViewItem ligne = new ListViewItem();
                    ligne.Text = tab.client[i].raisonSociale; // 1ère colonne
                    int k = 0;
                    for (int j = 0; j < tab.nbTickets; j++) // pour ne pas dépasser le nombre de tickets
                    {
                        if (tab.client[i].raisonSociale == tab.client[tab.ticket[j].numClient - 1].raisonSociale) // nous permet d'avoir le nombre de tickets par personnes 
                        {
                            k++;
                        }

                    }
                    //configuration d'une ligne de la liste
                    ligne.SubItems.Add(k.ToString()); // 2ème colonne 
                    lvNbTicket.Items.Add(ligne); // affiche la ligne
                }
            }
        }
    }
}
