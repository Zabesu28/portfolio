﻿
namespace prj_wfrm_centreCall_tickets
{
    partial class frmNouveauTicket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btTicket = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.Objet = new System.Windows.Forms.Label();
            this.tbObjet = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbClient = new System.Windows.Forms.ComboBox();
            this.mcTicket = new System.Windows.Forms.MonthCalendar();
            this.SuspendLayout();
            // 
            // btTicket
            // 
            this.btTicket.Location = new System.Drawing.Point(507, 379);
            this.btTicket.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btTicket.Name = "btTicket";
            this.btTicket.Size = new System.Drawing.Size(141, 71);
            this.btTicket.TabIndex = 20;
            this.btTicket.Text = "Créer";
            this.btTicket.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 17);
            this.label3.TabIndex = 19;
            this.label3.Text = "Client :";
            // 
            // Objet
            // 
            this.Objet.AutoSize = true;
            this.Objet.Location = new System.Drawing.Point(389, 80);
            this.Objet.Name = "Objet";
            this.Objet.Size = new System.Drawing.Size(50, 17);
            this.Objet.TabIndex = 18;
            this.Objet.Text = "Objet :";
            // 
            // tbObjet
            // 
            this.tbObjet.Location = new System.Drawing.Point(445, 78);
            this.tbObjet.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbObjet.Name = "tbObjet";
            this.tbObjet.Size = new System.Drawing.Size(324, 22);
            this.tbObjet.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(404, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(185, 29);
            this.label1.TabIndex = 16;
            this.label1.Text = "Nouveau ticket";
            // 
            // cbClient
            // 
            this.cbClient.FormattingEnabled = true;
            this.cbClient.Location = new System.Drawing.Point(91, 78);
            this.cbClient.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbClient.Name = "cbClient";
            this.cbClient.Size = new System.Drawing.Size(233, 24);
            this.cbClient.TabIndex = 15;
            // 
            // mcTicket
            // 
            this.mcTicket.Location = new System.Drawing.Point(445, 160);
            this.mcTicket.Name = "mcTicket";
            this.mcTicket.TabIndex = 14;
            // 
            // frmNouveauTicket
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btTicket);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Objet);
            this.Controls.Add(this.tbObjet);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbClient);
            this.Controls.Add(this.mcTicket);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmNouveauTicket";
            this.Text = "frmNouveauTicket";
            this.Load += new System.EventHandler(this.frmNouveauTicket_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btTicket;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Objet;
        private System.Windows.Forms.TextBox tbObjet;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbClient;
        private System.Windows.Forms.MonthCalendar mcTicket;
    }
}