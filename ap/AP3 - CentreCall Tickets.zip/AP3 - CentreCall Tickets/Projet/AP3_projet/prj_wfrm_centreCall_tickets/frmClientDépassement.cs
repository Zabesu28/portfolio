﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prj_wfrm_centreCall_tickets
{
    public partial class frmClientDépassement : Form
    {
        public frmClientDépassement()
        {
            InitializeComponent();
        }

        private void frmClientDépassement_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < tab.nbClients; i++)
            {
                //configuration d'une ligne de la liste
                ListViewItem ligne = new ListViewItem();
                //1ère colonne = n° du client
                ligne.Text = tab.client[i].numero.ToString();
                //2ème colonne = raison sociale du client
                ligne.SubItems.Add(tab.client[i].raisonSociale);
                //7ème colonne = montant du dernier contrat au format monétaire
                ligne.SubItems.Add(String.Format("{0:C}", tab.client[i].montantContrat));
                //8ème colonne = montant cumulé des tickets imputés à ce contrat
                ligne.SubItems.Add(String.Format("{0:C}", tab.client[i].montantTickets));
                Single montantDepassement = tab.client[i].montantTickets - tab.client[i].montantContrat;
                tab.client[i].montantDepassement = montantDepassement;
                ligne.SubItems.Add(String.Format("{0:C}", tab.client[i].montantDepassement));

                //ajout de la ligne dans la liste 
                if (tab.client[i].montantTickets > tab.client[i].montantContrat)
                {
                    lvClient.Items.Add(ligne);
                }
            }
        }
    }
}
