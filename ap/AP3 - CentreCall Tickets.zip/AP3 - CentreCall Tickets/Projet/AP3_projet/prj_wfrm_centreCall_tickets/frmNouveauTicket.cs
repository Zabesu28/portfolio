﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prj_wfrm_centreCall_tickets
{
    public partial class frmNouveauTicket : Form
    {
        public frmNouveauTicket()
        {
            InitializeComponent();
        }

        private void frmNouveauTicket_Load(object sender, EventArgs e)
        {
            if (tab.nbTickets == 0)
            {
                MessageBox.Show("Aucun ticket", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                //parcours du tableau des centres d'appel
                for (int i = 0; i < tab.nbClients; i++)
                {

                    cbClient.Items.Add(tab.client[i].raisonSociale);


                    //ajout de la ligne dans la liste
                }
            }
        }

        private void btTicket_Click(object sender, EventArgs e)
        {
            int i = tab.nbTickets;
            tab.ticket[i].numero = i + 1;
            tab.ticket[i].dateOuverture = mcTicket.SelectionStart;
            tab.ticket[i].numClient = cbClient.SelectedIndex;
            MessageBox.Show(mcTicket.ToString());
            tab.ticket[i].objet = tbObjet.Text;
            tab.ticket[i].cloture = false;
            tab.nbTickets++;

            //ajout de la ligne dans la liste en renseignant toutes les colonne

        }


    }
}
