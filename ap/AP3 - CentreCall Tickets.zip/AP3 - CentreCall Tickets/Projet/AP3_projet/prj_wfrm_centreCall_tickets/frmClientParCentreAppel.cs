﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prj_wfrm_centreCall_tickets
{
    public partial class frmClientParCentreAppel : Form
    {
        public frmClientParCentreAppel()
        {
            InitializeComponent();
        }

        private void frmClientParCentreAppel_Load(object sender, EventArgs e)
        {
            for(int i = 0; i < tab.nbCentresAppel; i++)
            {
                liste_ville.Items.Add(tab.centreAppel[i].ville);
            }
        }

        private void btn_rechercher_Click(object sender, EventArgs e)
        {
            lv_ville.Items.Clear();
            string ville = liste_ville.SelectedItem.ToString();
            int ville1 = 0;

            for(int j = 0; j < tab.nbCentresAppel; j++)
            {
                if(tab.centreAppel[j].ville == ville)
                {
                    ville1 = ville1 + tab.centreAppel[j].numero;
                }
            }

            for(int k = 0; k < tab.nbClients; k++)
            {
                if(tab.client[k].centreAppel == ville1)
                {
                    ListViewItem ligne = new ListViewItem();

                    ligne.Text = tab.client[k].numero.ToString();
                    ligne.SubItems.Add(tab.client[k].raisonSociale);

                    lv_ville.Items.Add(ligne);
                }               
            }
        }
    }
}
