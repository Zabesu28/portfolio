﻿namespace prj_wfrm_centreCall_tickets
{
    partial class frmClientAfficherTous
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvClient = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbMoyContrat = new System.Windows.Forms.TextBox();
            this.tbTotTickets = new System.Windows.Forms.TextBox();
            this.tbTotContrat = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lvClient
            // 
            this.lvClient.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8});
            this.lvClient.FullRowSelect = true;
            this.lvClient.HideSelection = false;
            this.lvClient.Location = new System.Drawing.Point(3, 1);
            this.lvClient.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lvClient.Name = "lvClient";
            this.lvClient.Size = new System.Drawing.Size(1355, 669);
            this.lvClient.TabIndex = 1;
            this.lvClient.UseCompatibleStateImageBehavior = false;
            this.lvClient.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "N°";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Raison sociale";
            this.columnHeader2.Width = 150;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Centre appel";
            this.columnHeader3.Width = 80;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "NAF";
            this.columnHeader4.Width = 300;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Date contrat";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader5.Width = 120;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "durée";
            this.columnHeader6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Montant";
            this.columnHeader7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader7.Width = 120;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Valeur Tickets";
            this.columnHeader8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader8.Width = 120;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(360, 705);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(167, 17);
            this.label4.TabIndex = 15;
            this.label4.Text = "Valeur totale des tickets :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(728, 722);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(199, 17);
            this.label3.TabIndex = 14;
            this.label3.Text = "Durée moyenne des contrats :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(428, 442);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 17);
            this.label2.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 762);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 17);
            this.label1.TabIndex = 12;
            this.label1.Text = "Valeur totale des contrats :";
            // 
            // tbMoyContrat
            // 
            this.tbMoyContrat.Enabled = false;
            this.tbMoyContrat.Location = new System.Drawing.Point(924, 719);
            this.tbMoyContrat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbMoyContrat.Name = "tbMoyContrat";
            this.tbMoyContrat.Size = new System.Drawing.Size(100, 22);
            this.tbMoyContrat.TabIndex = 11;
            // 
            // tbTotTickets
            // 
            this.tbTotTickets.Enabled = false;
            this.tbTotTickets.Location = new System.Drawing.Point(555, 690);
            this.tbTotTickets.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbTotTickets.Name = "tbTotTickets";
            this.tbTotTickets.Size = new System.Drawing.Size(100, 22);
            this.tbTotTickets.TabIndex = 10;
            // 
            // tbTotContrat
            // 
            this.tbTotContrat.Enabled = false;
            this.tbTotContrat.Location = new System.Drawing.Point(206, 762);
            this.tbTotContrat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbTotContrat.Name = "tbTotContrat";
            this.tbTotContrat.Size = new System.Drawing.Size(100, 22);
            this.tbTotContrat.TabIndex = 9;
            // 
            // frmClientAfficherTous
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1296, 795);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbMoyContrat);
            this.Controls.Add(this.tbTotTickets);
            this.Controls.Add(this.tbTotContrat);
            this.Controls.Add(this.lvClient);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmClientAfficherTous";
            this.Text = "Clients - Tous";
            this.Load += new System.EventHandler(this.frmClientAfficherTous_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lvClient;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbMoyContrat;
        private System.Windows.Forms.TextBox tbTotTickets;
        private System.Windows.Forms.TextBox tbTotContrat;
    }
}