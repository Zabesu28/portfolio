﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prj_wfrm_centreCall_tickets
{
    public partial class frmNbTicketsParCentreAppel : Form
    {
        public frmNbTicketsParCentreAppel()
        {
            InitializeComponent();
        }

        private void frmNbTicketsParCentreAppel_Load(object sender, EventArgs e)
        {
            if (tab.nbCentresAppel == 0)
            {
                MessageBox.Show("Aucun client", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                //parcours du tableau des centres d'appel
                for (int i = 0; i < tab.nbCentresAppel; i++)
                {
                    ListViewItem ligne = new ListViewItem();
                    ligne.Text = tab.centreAppel[i].ville;   // 1ère colonne
                    int k = 0;
                    for (int j = 0; j < tab.nbTickets; j++) // pour ne pas dépasser le nombre de tickets
                    {
                        if (tab.centreAppel[i].ville == tab.centreAppel[tab.client[tab.ticket[j].numClient - 1].centreAppel - 1].ville) // nous permet d'avoir le nombre de persnne par ville
                        {
                            k++;
                        }

                    }
                    //configuration d'une ligne de la liste
                    ligne.SubItems.Add(k.ToString()); // 2ème colonne
                    lvNbTicketCentreAppel.Items.Add(ligne); // ajoute la ligne
                }
            }
        }
    }
}
