﻿
namespace prj_wfrm_centreCall_tickets
{
    partial class frmNbTicketsParClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvNbTicket = new System.Windows.Forms.ListView();
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // lvNbTicket
            // 
            this.lvNbTicket.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader9,
            this.columnHeader10});
            this.lvNbTicket.FullRowSelect = true;
            this.lvNbTicket.HideSelection = false;
            this.lvNbTicket.Location = new System.Drawing.Point(11, 11);
            this.lvNbTicket.Margin = new System.Windows.Forms.Padding(2);
            this.lvNbTicket.Name = "lvNbTicket";
            this.lvNbTicket.Size = new System.Drawing.Size(433, 587);
            this.lvNbTicket.TabIndex = 3;
            this.lvNbTicket.UseCompatibleStateImageBehavior = false;
            this.lvNbTicket.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Raison sociale";
            this.columnHeader9.Width = 200;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Nombre de ticket";
            this.columnHeader10.Width = 200;
            // 
            // frmNbTicketsParClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lvNbTicket);
            this.Name = "frmNbTicketsParClient";
            this.Text = "frmNbTicketsParClient";
            this.Load += new System.EventHandler(this.frmNbTicketsParClient_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lvNbTicket;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
    }
}