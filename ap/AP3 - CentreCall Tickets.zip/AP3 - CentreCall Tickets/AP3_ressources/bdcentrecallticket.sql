-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : Dim 22 nov. 2020 à 12:26
-- Version du serveur :  8.0.21
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `bdcentrecallticket2`
--

-- --------------------------------------------------------

--
-- Structure de la table `tb_centre`
--

DROP TABLE IF EXISTS `tb_centre`;
CREATE TABLE IF NOT EXISTS `tb_centre` (
  `CNT_NUM` int NOT NULL,
  `CNT_VILLE` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
  PRIMARY KEY (`CNT_NUM`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `tb_centre`
--

INSERT INTO `tb_centre` (`CNT_NUM`, `CNT_VILLE`) VALUES
(1, 'Lille'),
(2, 'Paris'),
(3, 'Tours'),
(4, 'Bordeaux'),
(5, 'Toulouse');

-- --------------------------------------------------------

--
-- Structure de la table `tb_client`
--

DROP TABLE IF EXISTS `tb_client`;
CREATE TABLE IF NOT EXISTS `tb_client` (
  `CLN_NUM` int NOT NULL,
  `CLN_RAISON_SOCIALE` varchar(30) CHARACTER SET utf8mb4 NOT NULL,
  `CLN_CNT_NUM` int NOT NULL,
  `CLN_NAF_CODE` int NOT NULL,
  `CLN_DATE_CONTRAT` date NOT NULL,
  `CLN_DUREE_MOIS` int NOT NULL,
  `CLN_MT_CONTRAT` decimal(10,2) NOT NULL,
  `CLN_MT_TICKET` decimal(10,2) NOT NULL,
  PRIMARY KEY (`CLN_NUM`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `tb_client`
--

INSERT INTO `tb_client` (`CLN_NUM`, `CLN_RAISON_SOCIALE`, `CLN_CNT_NUM`, `CLN_NAF_CODE`, `CLN_DATE_CONTRAT`, `CLN_DUREE_MOIS`, `CLN_MT_CONTRAT`, `CLN_MT_TICKET`) VALUES
(1, 'GAUFRETTES MIA', 1, 10, '2019-01-12', 36, '21000.00', '12484.93'),
(2, 'VERT IMPRIMERIE', 2, 18, '2018-12-01', 36, '21000.00', '13290.41'),
(3, 'ECOLOTRI', 4, 38, '2018-02-10', 30, '17500.00', '18928.77'),
(4, 'GARAGE CENTRAL', 1, 45, '2019-04-15', 48, '28000.00', '10701.37'),
(5, 'HOTEL DU PRIEURE', 4, 55, '2018-06-01', 36, '21000.00', '16800.00'),
(6, 'TELEPLUS', 2, 61, '2017-05-01', 40, '30000.00', '24394.52'),
(7, 'INFOSERVICES', 1, 62, '2019-03-01', 36, '21000.00', '11564.38'),
(8, 'LORDEL PUBLICITE', 3, 73, '2020-05-01', 60, '35000.00', '3375.34'),
(9, 'APPEL SERVICES', 4, 82, '2020-08-01', 12, '7000.00', '1610.96'),
(10, 'MAGICREPRO', 3, 18, '2018-07-01', 24, '14000.00', '16224.66'),
(11, 'TRI TOUT', 1, 38, '2020-06-01', 36, '21000.00', '2780.82'),
(12, 'MOTO CONFORT', 2, 45, '2020-09-01', 12, '7000.00', '1016.44'),
(13, 'AUBERGE DE LA TRUITE', 2, 55, '2019-08-01', 36, '21000.00', '8630.14'),
(14, 'TELECOM POLLUX', 3, 61, '2018-02-01', 36, '21000.00', '19101.37'),
(15, 'IMPRIMERIE VILLAGE', 5, 18, '2019-07-01', 24, '14000.00', '9224.66'),
(16, 'DECHETS RECYCL', 1, 38, '2018-07-01', 48, '28000.00', '16224.66'),
(17, 'AUTO PLUS', 5, 45, '2020-05-01', 36, '21000.00', '3375.34'),
(18, 'AUBERGE MAYOL', 4, 55, '2019-04-01', 24, '14000.00', '10969.86'),
(19, 'TELE VIDEO ', 5, 61, '2018-11-15', 24, '14000.00', '13597.26'),
(20, 'TOUT POUR LA PUB', 2, 73, '2018-02-03', 36, '21000.00', '19063.01'),
(21, 'PUBETUD', 2, 73, '2019-09-05', 48, '28000.00', '7958.90'),
(22, 'TELECOM LOUVAIN', 5, 61, '2020-09-04', 12, '7000.00', '958.90'),
(23, 'IMPRIMERIE LEFORT', 3, 18, '2020-06-05', 10, '6000.00', '2704.11'),
(24, 'TRI POUR TOUS', 1, 38, '2019-03-04', 36, '21000.00', '11506.85'),
(25, 'TELECOM EFFI', 5, 61, '2019-05-05', 6, '5000.00', '10317.81'),
(26, 'ETUDES MOLLIN', 1, 73, '2020-04-18', 24, '14000.00', '3624.66'),
(27, 'IMPRIMERIE DU CENTRE', 2, 18, '2020-04-09', 12, '7000.00', '3797.26'),
(28, 'TRI NEUF', 5, 38, '2019-05-25', 24, '14000.00', '9934.25'),
(29, 'TELECOM BOURGUEIL', 3, 61, '2019-06-05', 24, '14000.00', '9723.29'),
(30, 'ETUDES FRANCK', 1, 73, '2020-05-05', 36, '21000.00', '3298.63');

-- --------------------------------------------------------

--
-- Structure de la table `tb_naf`
--

DROP TABLE IF EXISTS `tb_naf`;
CREATE TABLE IF NOT EXISTS `tb_naf` (
  `NAF_CODE` int NOT NULL,
  `NAF_INTITULE` varchar(500) NOT NULL,
  PRIMARY KEY (`NAF_CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `tb_naf`
--

INSERT INTO `tb_naf` (`NAF_CODE`, `NAF_INTITULE`) VALUES
(1, 'Culture et production animale, chasse et services annexes'),
(2, 'Sylviculture et exploitation forestière'),
(3, 'Pêche et aquaculture'),
(4, 'Inconnu'),
(5, 'Extraction de houille et de lignite'),
(6, 'Extraction d\'hydrocarbures'),
(7, 'Extraction de minerais métalliques'),
(8, 'Autres industries extractives'),
(9, 'Services de soutien aux industries extractives'),
(10, 'Industries alimentaires'),
(11, 'Fabrication de boissons'),
(12, 'Fabrication de produits à base de tabac'),
(13, 'Fabrication de textiles'),
(14, 'Industrie de l\'habillement'),
(15, 'Industrie du cuir et de la chaussure'),
(16, 'Travail du bois et fabrication d\'articles en bois et en liège, à lexception des meubles, fabrication darticles en vannerie et sparterie'),
(17, 'Industrie du papier et du carton'),
(18, 'Imprimerie et reproduction d\'enregistrements'),
(19, 'Cokéfaction et raffinage'),
(20, 'Industrie chimique'),
(21, 'Industrie pharmaceutique'),
(22, 'Fabrication de produits en caoutchouc et en plastique'),
(23, 'Fabrication d\'autres produits minéraux non métalliques'),
(24, 'Métallurgie'),
(25, 'Fabrication de produits métalliques, à lexception des machines et des équipements'),
(26, 'Fabrication de produits informatiques, électroniques et optiques'),
(27, 'Fabrication d\'équipements électriques'),
(28, 'Inconnu'),
(29, 'Industrie automobile'),
(30, 'Fabrication d\'autres matériels de transport'),
(31, 'Fabrication de meubles'),
(32, 'Autres industries manufacturières'),
(33, 'Réparation et installation de machines et d\'équipements '),
(34, 'Inconnu'),
(35, 'Production et distribution d\'électricité, de gaz, de vapeur et d\'air conditionné'),
(36, 'Captage, traitement et distribution d\'eau '),
(37, 'Collecte et traitement des eaux usées'),
(38, 'Collecte, traitement et élimination des déchets ,récupération'),
(39, 'Dépollution et autres services de gestion des déchets'),
(40, 'Inconnu'),
(41, 'Construction de bâtiments '),
(42, 'Génie civil'),
(43, 'Travaux de construction spécialisés '),
(44, 'Inconnu'),
(45, 'Commerce et réparation d\'automobiles et de motocycles'),
(46, 'Commerce de gros, à lexception des automobiles et des motocycles'),
(47, 'Commerce de détail, à lexception des automobiles et des motocycles'),
(48, 'Inconnu'),
(49, 'Transports terrestres et transport par conduites'),
(50, 'Transports par eau'),
(51, 'Transports aériens'),
(52, 'Entreposage et services auxiliaires des transports'),
(53, 'Activités de poste et de courrier'),
(54, 'Inconnu'),
(55, 'Hébergement'),
(56, 'Restauration'),
(57, 'Inconnu'),
(58, 'Édition'),
(59, 'Production de films cinématographiques, de vidéo et de programmes de télévision, enregistrement sonore et édition musicale'),
(60, 'Programmation et diffusion'),
(61, 'Télécommunications'),
(62, 'Programmation, conseil et autres activités informatiques '),
(63, 'Services d\'information'),
(64, 'Activités des services financiers, hors assurance et caisses de retraite'),
(65, 'Assurance'),
(66, 'Activités auxiliaires de services financiers et d\'assurance '),
(67, 'Inconnu'),
(68, 'Activités immobilières'),
(69, 'Activités juridiques et comptables'),
(70, 'Activités des sièges sociaux, conseil de gestion'),
(71, 'Activités d\'architecture et d\'ingénierie, activités de contrôle et analyses techniques'),
(72, 'Recherche-développement scientifique'),
(73, 'Publicité et études de marché'),
(74, 'Autres activités spécialisées, scientifiques et techniques'),
(75, 'Activités vétérinaires'),
(76, 'Inconnu'),
(77, 'Activités de location et location-bail'),
(78, 'Activités liées à l\'emploi'),
(79, 'Activités des agences de voyage, voyagistes, services de réservation et activités connexes'),
(80, 'Enquêtes et sécurité'),
(81, 'Services relatifs aux bâtiments et aménagement paysager'),
(82, 'Activités administratives et autres activités de soutien aux entreprises'),
(83, 'Inconnu'),
(84, 'Administration publique et défense, sécurité sociale obligatoire'),
(85, 'Enseignement'),
(86, 'Activités pour la santé humaine'),
(87, 'Hébergement médico-social et social'),
(88, 'Action sociale sans hébergement'),
(89, 'Inconnu'),
(90, 'Activités créatives, artistiques et de spectacle '),
(91, 'Bibliothèques, archives, musées et autres activités culturelles'),
(92, 'Organisation de jeux de hasard et d\'argent'),
(93, 'Activités sportives, récréatives et de loisirs'),
(94, 'Activités des organisations associatives'),
(95, 'Réparation d\'ordinateurs et de biens personnels et domestiques'),
(96, 'Autres services personnels'),
(97, 'Activités des ménages en tant qu\'employeurs de personnel domestique'),
(98, 'Activités indifférenciées des ménages en tant que producteurs de biens et services pour usage propre'),
(99, 'Activités des organisations et organismes extraterritoriaux');

-- --------------------------------------------------------

--
-- Structure de la table `tb_technicien`
--

DROP TABLE IF EXISTS `tb_technicien`;
CREATE TABLE IF NOT EXISTS `tb_technicien` (
  `TCH_NUM` int NOT NULL,
  `TCH_NOM` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
  `TCH_PRENOM` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
  `TCH_TX_HORAIRE` float NOT NULL,
  PRIMARY KEY (`TCH_NUM`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `tb_technicien`
--

INSERT INTO `tb_technicien` (`TCH_NUM`, `TCH_NOM`, `TCH_PRENOM`, `TCH_TX_HORAIRE`) VALUES
(1, 'PETOU', 'Olivier', 35.6),
(2, 'MARECHAL', 'Louise', 32),
(3, 'BERTIN', 'Alice', 28.5),
(4, 'LESEIGNEUR', 'Paul', 45),
(5, 'MARJAK', 'Alexis', 48),
(6, 'LELEU', 'Myriam', 39.75),
(7, 'LECALIER', 'Didier', 22.8),
(8, 'MAZE', 'Hélène', 23.25),
(9, 'GUEROULT', 'Pierre', 35.6),
(10, 'SAILLARD', 'Jeanne', 32.9);

-- --------------------------------------------------------

--
-- Structure de la table `tb_ticket`
--

DROP TABLE IF EXISTS `tb_ticket`;
CREATE TABLE IF NOT EXISTS `tb_ticket` (
  `TCK_NUM_INTERVENTION` int NOT NULL,
  `TCK_DATE` date NOT NULL,
  `TCK_CLN_NUM` int NOT NULL,
  `TCK_OBJET` varchar(50) CHARACTER SET utf8mb4 NOT NULL,
  `TCK_CLOTURE` varchar(3) CHARACTER SET utf8mb4 NOT NULL,
  `TCK_DATE_CLOTURE` date DEFAULT NULL,
  `TCK_NB_HEURES` int DEFAULT NULL,
  `TCK_TCH_NUM` int NOT NULL,
  PRIMARY KEY (`TCK_NUM_INTERVENTION`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `tb_ticket`
--

INSERT INTO `tb_ticket` (`TCK_NUM_INTERVENTION`, `TCK_DATE`, `TCK_CLN_NUM`, `TCK_OBJET`, `TCK_CLOTURE`, `TCK_DATE_CLOTURE`, `TCK_NB_HEURES`, `TCK_TCH_NUM`) VALUES
(1, '2020-11-02', 22, 'Bug logiciel PrestaPlus', 'NON', NULL, 0, 2),
(2, '2020-11-02', 18, 'Panne serveur de fichiers', 'OUI', NULL, 5, 2),
(3, '2020-11-02', 29, 'Mise à jour antivirus', 'OUI', '2020-11-02', 1, 7),
(4, '2020-11-02', 25, 'Serveur web indisponible', 'OUI', '2020-11-03', 2, 1),
(5, '2020-11-02', 2, 'Imprimante hors connexion', 'OUI', '2020-11-02', 1, 7),
(6, '2020-11-02', 5, 'Aide utilisation logiciel PrestaPlus', 'OUI', '2020-11-02', 1, 6),
(7, '2020-11-02', 8, 'Mise à jour antivirus', 'OUI', '2020-11-02', 1, 3),
(8, '2020-11-02', 13, 'Panne routeur', 'OUI', '2020-11-03', 2, 9),
(9, '2020-11-02', 14, 'Serveur web indisponible', 'OUI', '2020-11-03', 2, 10),
(10, '2020-11-02', 20, 'Mise à jour antivirus', 'OUI', '2020-11-02', 1, 3),
(11, '2020-11-02', 21, 'Aide utilisation logiciel PrestaPlus', 'OUI', '2020-11-02', 1, 6),
(12, '2020-11-02', 24, 'Panne serveur de fichiers', 'NON', NULL, 0, 5),
(13, '2020-11-02', 25, 'Erreur dans les sauvegardes', 'NON', NULL, 0, 6),
(14, '2020-11-02', 9, 'Panne routeur', 'NON', NULL, 0, 8),
(15, '2020-11-02', 30, 'Mise à jour antivirus', 'OUI', '2020-11-02', 1, 7),
(16, '2020-11-03', 22, 'Panne routeur', 'OUI', '2020-11-03', 2, 2),
(17, '2020-11-03', 18, 'Panne serveur de fichiers', 'OUI', '2020-11-04', 3, 5),
(18, '2020-11-03', 21, 'Erreur dans les sauvegardes', 'OUI', '2020-11-03', 3, 4),
(19, '2020-11-03', 25, 'Bug logiciel PrestaPlus', 'NON', NULL, 0, 10),
(20, '2020-11-03', 13, 'Aide utilisation logiciel PrestaPlus', 'OUI', '2020-11-03', 3, 8),
(21, '2020-11-03', 9, 'Serveur web indisponible', 'OUI', '2020-11-03', 3, 10),
(22, '2020-11-04', 18, 'Mise à jour antivirus', 'OUI', '2020-11-04', 1, 2),
(23, '2020-11-04', 25, 'Panne serveur de fichiers', 'NON', NULL, 0, 3),
(24, '2020-11-04', 29, 'Aide utilisation logiciel PrestaPlus', 'OUI', '2020-11-04', 1, 6),
(25, '2020-11-04', 30, 'Imprimante hors connexion', 'OUI', '2020-11-04', 1, 7);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
