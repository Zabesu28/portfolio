﻿using System;
using System.Collections.Generic;
using System.IO;    //ajoute bibliothèque de commande
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AP1
{

    public partial class Cryptage : Form
    {   // tableau avec toute les lettres de l'aplhabet
        string[] CrypteE = new string[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
        public Cryptage()
        {
            InitializeComponent();
        }

        private bool ParMoisE()   // fonction booléen permettant de vérifier si un mot de passe à déja été créé ce mois pour l'entrée du bâtiment 
        {
            var reader = new StreamReader(File.OpenRead(@"../../../../../digicod_secure.csv")); // création d'une variable qui va ouvrir le fichier selectionné
            List<string> Mois = new List<string>();                                             // on défini une liste en lui donnant un nom
            List<string> autorisation = new List<string>();                                     // on défini une liste en lui donnant un nom
            while (!reader.EndOfStream)                                                         // tant que l'on est pas à la fin du tableau
            {
                var line = reader.ReadLine();                      // variable qui va lire le tableau excel
                var values = line.Split(';');                      // on passe d'une cellule à une autre en sautant les ; se trouvant entre les cellules.
                Mois.Add(values[1]);                               // la colonne ou se trouve les valeurs recherchés (la colonne de la date de début des mots de passe ici)
                autorisation.Add(values[0]);                       // la colonne ou se trouve les valeurs recherchés (la colonne des autorisations)
            }
            for (int i = 0; i < Mois.Count; i++)                   // va lire les valeurs de la colonne sélection (la colonne de la date de fin des mots de passe ici)
            {
                DateTime thisDay = DateTime.Today;                 // donne un nom à la date du jour
                int month = thisDay.Month;                         // le mois d'aujourd'hui
                int month1 = month + 1;                            // le mois d'aujourd'hui + 1

                if (Mois[i].Substring(3, 2) == month1.ToString() && autorisation[i] == "E")  // Si l'endroit où le mois se situe est égale au mois d'aujourd'hui et que l'autorisation du mot de passe est l'entrée du bâtiment
                {
                    return true;     // retourne vrai
                }
                else if (Mois[i].Substring(3, 1) == month1.ToString() && autorisation[i] == "E") // Sinon Si l'endroit où le mois (3, 1 car pour les mois inférieur à 10 le 0 n'est pas là) se situe est égale au mois d'aujourd'hui et que l'autorisation du mot de passe est l'entrée du bâtiment
                {
                    return true;     // retourne vrai
                }

                reader.Close();      // ferme le fichier excel
            }
            return false;       // retourne faux

        }
        private bool ParMoisI()   // fonction booléen permettant de vérifier si un mot de passe à déja été créé ce mois pour la salle informatique
        {
            var reader = new StreamReader(File.OpenRead(@"../../../../../digicod_secure.csv")); // création d'une variable qui va ouvrir le fichier selectionné
            List<string> Mois = new List<string>();                                             // on défini une liste en lui donnant un nom
            List<string> autorisation = new List<string>();                                     // on défini une liste en lui donnant un nom
            while (!reader.EndOfStream)                                                         // tant que l'on est pas à la fin du tableau
            {
                var line = reader.ReadLine();                     // variable qui va lire le tableau excel
                var values = line.Split(';');                     // on passe d'une cellule à une autre en sautant les ; se trouvant entre les cellules.
                Mois.Add(values[1]);                              // la colonne ou se trouve les valeurs recherchés (la colonne de la date de début des mots de passe ici)
                autorisation.Add(values[0]);                      // va lire les valeurs de la colonne sélection (la colonne des autorisations ici)
            }
            for (int i = 0; i < Mois.Count; i++)                  // va lire les valeurs de la colonne sélection (la colonne de la date de fin des mots de passe ici)
            {
                DateTime thisDay = DateTime.Today;                // donne un nom à la date du jour
                int month = thisDay.Month;                        // le mois d'aujourd'hui
                int month1 = month + 1;                           // le mois d'aujourd'hui + 1

                if (Mois[i].Substring(3, 2) == month1.ToString() && autorisation[i] == "I") // Si l'endroit où le mois se situe est égale au mois d'aujourd'hui + 1 et que l'autorisation du mot de passe est la salle informatique
                {
                    return true;     // retourne vrai
                }
                else if (Mois[i].Substring(3, 1) == month1.ToString() && autorisation[i] == "I") // Sinon Si l'endroit où le mois (3, 1 car pour les mois inférieur à 10 le 0 n'est pas là) se situe est égale au mois d'aujourd'hui et que l'autorisation du mot de passe est la salle informatique
                {
                    return true;    // retourne vrai
                }

                reader.Close();     // ferme le fichier excel
            }
            return false;       // retourne faux 

        }

        private string CrypteEts(string mdp)       // fonction permettant de crypter des mots de passe pour l'entrée du bâtiment    
        {
            string mdpCrypt = "";                                         // defini mdpCrypt comme chaine de caractère
            mdp = mdp.ToUpper();                                          // le mdp sera en majuscule
            for(int i = 0; i < mdp.Length; i++)                           // lit le nombre de caractère rentré
            { 
                for (int k = 0; k < CrypteE.Length; k++)                  // lit le nombre de caractère dans le tableau
                {
                    if(mdp.Substring(i,1) == CrypteE[k])                  // prend chaque lettre du mot de passe et regarde sa position dans le tableau
                    {
                        mdpCrypt = mdpCrypt + CrypteE[(k + 10) % 26];    // mot de passe cryté = la position du mot de passe + 10 mudulo 26
                    }
                }
            }
            return mdpCrypt;   // retourne le mot de passe crypté
        }

        private string CrypteInf(string mdp)       // fonction permettant de crypter des mots de passe pour la salle informatique
        {
            string mdpCrypt = "";                                         // defini mdpCrypt comme chaine de caractère
            mdp = mdp.ToUpper();                                          // le mdp sera en majuscule
            for (int i = 0; i < mdp.Length; i++)                           // lit le nombre de caractère rentré
            {
                for (int k = 0; k < CrypteE.Length; k++)                  // lit le nombre de caractère dans le tableau
                {
                    if (mdp.Substring(i, 1) == CrypteE[k])                  // prend chaque lettre du mot de passe et regarde sa position dans le tableau
                    {
                        mdpCrypt = mdpCrypt + CrypteE[(33 * k + 1) % 26];    // mot de passe cryté = multiplie la position du mot de passe par 33 + 1 mudulo 26
                    }
                }
            }
            return mdpCrypt;    // retourne le mot de passe crypté
        } 

        private void btnCryptageEntB_Click(object sender, EventArgs e)    // bouton qui va crypter le mot de passe de l'entrée du bâtiment
        {
            
            tbDigiB.Text = CrypteEts(tbEntB.Text);       // crypte le mot de passe entrée dans la zone de texte tbEntB et rempli tbDigiB avec le mot de passe crypté

            if(tbDigiB.Text.Length < 6)       // si la longueur du mot de passe crypté est inférieur à 6
            {
                tbEntB.Clear();               // vide la zone de texte
                tbDigiB.Clear();              // vide la zone de texte
                MessageBox.Show("Vous n'avez pas respecté les conditions pour crypter le mot de passe destiné à l'entrée du batiment.");        // message d'alerte
            }
            else
            {

                if (ParMoisE() == true)   // si il y a déja eu un mot de passe de crée ce mois-ci pour l'entrée du bâtiment
                {
                    tbEntB.Clear();           // vide la zone de texte
                    tbDigiB.Clear();          // vide la zone de texte
                    MessageBox.Show("Echec de la création du mot de passe. Un mot de passe à déja été créé pour l'entrée du batiment ce mois-ci.");    // message d'alerte

                }
                else
                {
                    DateTime DateActuelle = DateTime.Today;      // nomme la date du jour DateActuelle
                    int year = DateActuelle.Year;                // nomme l'année de la date actuelle year
                    int month = DateActuelle.Month;              // nomme le mois de la date actuelle month
                    int month1 = month + 1;                      // nomme le mois de la date actuelle + 1

                                                                                         //DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month) prend le nombre de jour du mois actuelle, ce qui nous donne donc le dernier jour du mois actuelle
                    String secure = "E" + ";" + "01" + "/" + month1 + "/" + year + ";" + DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month) + "/" + 0 + month1 + "/" + year + ";" + tbDigiB.Text + "\n";   //  nomme ce que l'on va écrire 
                    File.AppendAllText(@"../../../../../digicod_secure.csv", secure);    // écrit dans le tableau excel les informations données précédemment
                    MessageBox.Show("Le mot de passe crypté destiné à l'entrée du bâtiment pour le mois prochain à bien été créé.");                  // message d'alerte

                }
                
                
            }
            btnCryptageEntB.Enabled = false;        // bouton de cryptage de l'entrée du batiment grisé
            
        }

        private void btnCryptageSalleI_Click(object sender, EventArgs e)    // bouton qui va crypter le mot de passe de la salle informatique
        {
            tbDigiSI.Text = CrypteInf(tbSalleI.Text);         // crypte le mot de passe entrée dans la zone de texte tbEntB et rempli tbDigiB avec le mot de passe crypté

            if (tbDigiSI.Text.Length < 6)             // si la longueur du mot de passe crypté est inférieur à 6
            {
                tbSalleI.Clear();                   // vide la zone de texte
                tbDigiSI.Clear();                   // vide la zone de texte
                MessageBox.Show("Vous n'avez pas respecté les conditions pour crypter le mot de passe destiné à la salle informatique.");  // message d'alerte
            }
            else
            {
                if(ParMoisI() == true)              // si il y a déja eu un mot de passe de crée ce mois-ci pour la salle informatique
                {
                    tbSalleI.Clear();           // vide la zone de texte
                    tbDigiSI.Clear();           // vide la zone de texte
                    MessageBox.Show("Echec de la création du mot de passe. Un mot de passe à déja été créé pour la salle informatique ce mois-ci.");   // message d'alerte
                }
                else
                {
                    DateTime DateActuelle = DateTime.Today;     // nomme la date du jour DateActuelle
                    int year = DateActuelle.Year;               // nomme l'année de la date actuelle year
                    int month = DateActuelle.Month;             // nomme le mois de la date actuelle month
                    int month1 = month + 1;                     // nomme le mois de la date actuelle + 1

                                                                                        //DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month) prend le nombre de jour du mois actuelle, ce qui nous donne donc le dernier jour du mois actuelle
                    String secure = "I" + ";" + "01" + "/" + month1 + "/" + year + ";" + DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month) + "/" + 0 + month1 + "/" + year + ";" + tbDigiSI.Text + "\n";    //  nomme ce que l'on va écrire 
                    File.AppendAllText(@"../../../../../digicod_secure.csv", secure);          // écrit dans le tableau excel les informations données précédemment
                    MessageBox.Show("Le mot de passe crypté destiné à la salle informatique pour le mois prochain à bien été créé.");                 // message d'alerte
                }
                
            }
            btnCryptageSalleI.Enabled = false;          // bouton de cryptage de la salle informatique grisé

        }

        private void tbEntB_TextChanged(object sender, EventArgs e)   // dégrise le bouton de cryptage quand le tbEntB est égale à 6 caractères. Le regrise quand ce n'est pas le cas.
        {
            if (tbEntB.Text.Length == 6)
            {
                btnCryptageEntB.Enabled = true;             // bouton dégrisé
            }
            else
            {
                btnCryptageEntB.Enabled = false;            // bouton regrisé
            }
            if (tbSalleI.Text.Length == 6)
            {
                btnCryptageSalleI.Enabled = true;           // bouton dégrisé
            }
            else
            {
                btnCryptageSalleI.Enabled = false;          // bouton regrisé
            }
        }
        
        private void tbSalleI_TextChanged(object sender, EventArgs e)  // dégrise le bouton de cryptage quand le tbSalleI est égale à 6 caractères. Le regrise quand ce n'est pas le cas.
        {
            if (tbEntB.Text.Length == 6)
            {
                btnCryptageEntB.Enabled = true;             // bouton dégrisé
            }
            else
            {
                btnCryptageEntB.Enabled = false;            // bouton regrisé
            }
            if (tbSalleI.Text.Length == 6)
            {
                btnCryptageSalleI.Enabled = true;           // bouton dégrisé
            }
            else
            {
                btnCryptageSalleI.Enabled = false;          // bouton regrisé
            }
        }

        private void btnQuitter_Click(object sender, EventArgs e)
        {
            Application.Exit();
        } // ferme le programme

        private void btnReset_Click(object sender, EventArgs e)      // réinitialise le contenu des textbox presente dans l'interface de cryptage
        {
            tbDigiSI.Clear();
            tbDigiB.Clear();
            tbSalleI.Clear();
            tbEntB.Clear();
        }   

        private void btnRetour_Click(object sender, EventArgs e)    // permet de retourner à l'interface précédent (ici l'interface de connexion)
        {
            MessageBox.Show("Vous allez être redirigé vers la page de connexion.");     // Message d'alerte
            Form1 f = new Form1();                                                      // Donne un nom à la page que l'on va ouvrir
            f.Show();                                                                   // Ouvre la page
            this.Hide();                                                                // ferme la page précédente
        }

        private void Cryptage_Load(object sender, EventArgs e)
        {
            DateTime DateTime = DateTime.Today;     // nomme la date du jour DateActuelle 
            int day = DateTime.Day;                 // nomme le jour de la date actuelle day
            if ((DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month) -3).ToString() == day.ToString())  // si le total de jour dans le mois - 3 = le jour d'aujourd'hui
            {
                MessageBox.Show("Il vous reste 3 jours pour crypter les mots de passe du prochain mois.");    // Message d'alerte
            }
        }  // avertit l'administrateur 3 jours avant la date d'expiration des mots de passe
    }

    }


