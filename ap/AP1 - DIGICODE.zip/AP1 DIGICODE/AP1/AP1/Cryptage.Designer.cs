﻿
namespace AP1
{
    partial class Cryptage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbEntB = new System.Windows.Forms.TextBox();
            this.tbDigiB = new System.Windows.Forms.TextBox();
            this.tbSalleI = new System.Windows.Forms.TextBox();
            this.tbDigiSI = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnCryptageEntB = new System.Windows.Forms.Button();
            this.gBSallaInfo = new System.Windows.Forms.GroupBox();
            this.btnCryptageSalleI = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnQuitter = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnRetour = new System.Windows.Forms.Button();
            this.gBSallaInfo.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(185, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(412, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cryptage de mot de passe";
            // 
            // tbEntB
            // 
            this.tbEntB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbEntB.Location = new System.Drawing.Point(179, 31);
            this.tbEntB.Name = "tbEntB";
            this.tbEntB.Size = new System.Drawing.Size(125, 27);
            this.tbEntB.TabIndex = 1;
            this.tbEntB.TextChanged += new System.EventHandler(this.tbEntB_TextChanged);
            // 
            // tbDigiB
            // 
            this.tbDigiB.Enabled = false;
            this.tbDigiB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbDigiB.Location = new System.Drawing.Point(179, 94);
            this.tbDigiB.Name = "tbDigiB";
            this.tbDigiB.Size = new System.Drawing.Size(125, 27);
            this.tbDigiB.TabIndex = 2;
            // 
            // tbSalleI
            // 
            this.tbSalleI.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbSalleI.Location = new System.Drawing.Point(185, 44);
            this.tbSalleI.Name = "tbSalleI";
            this.tbSalleI.Size = new System.Drawing.Size(125, 27);
            this.tbSalleI.TabIndex = 3;
            this.tbSalleI.TextChanged += new System.EventHandler(this.tbSalleI_TextChanged);
            // 
            // tbDigiSI
            // 
            this.tbDigiSI.Enabled = false;
            this.tbDigiSI.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbDigiSI.Location = new System.Drawing.Point(185, 103);
            this.tbDigiSI.Name = "tbDigiSI";
            this.tbDigiSI.Size = new System.Drawing.Size(125, 27);
            this.tbDigiSI.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label2.Location = new System.Drawing.Point(6, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(167, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Mot de passe à crypter :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label3.Location = new System.Drawing.Point(96, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Digicode :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(120, 271);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 20);
            this.label4.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(132, 273);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 20);
            this.label6.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(12, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(167, 20);
            this.label5.TabIndex = 14;
            this.label5.Text = "Mot de passe à crypter :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.Location = new System.Drawing.Point(102, 106);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 20);
            this.label9.TabIndex = 17;
            this.label9.Text = "Digicode :";
            // 
            // btnCryptageEntB
            // 
            this.btnCryptageEntB.BackColor = System.Drawing.Color.SkyBlue;
            this.btnCryptageEntB.BackgroundImage = global::AP1.Properties.Resources.secu;
            this.btnCryptageEntB.Enabled = false;
            this.btnCryptageEntB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCryptageEntB.ForeColor = System.Drawing.Color.Cyan;
            this.btnCryptageEntB.Location = new System.Drawing.Point(354, 31);
            this.btnCryptageEntB.Name = "btnCryptageEntB";
            this.btnCryptageEntB.Size = new System.Drawing.Size(150, 90);
            this.btnCryptageEntB.TabIndex = 18;
            this.btnCryptageEntB.Text = "Crypter le mot de passe";
            this.btnCryptageEntB.UseVisualStyleBackColor = false;
            this.btnCryptageEntB.Click += new System.EventHandler(this.btnCryptageEntB_Click);
            // 
            // gBSallaInfo
            // 
            this.gBSallaInfo.BackColor = System.Drawing.Color.LightBlue;
            this.gBSallaInfo.Controls.Add(this.btnCryptageSalleI);
            this.gBSallaInfo.Controls.Add(this.label5);
            this.gBSallaInfo.Controls.Add(this.tbSalleI);
            this.gBSallaInfo.Controls.Add(this.label9);
            this.gBSallaInfo.Controls.Add(this.tbDigiSI);
            this.gBSallaInfo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.gBSallaInfo.ForeColor = System.Drawing.Color.Red;
            this.gBSallaInfo.Location = new System.Drawing.Point(12, 315);
            this.gBSallaInfo.Name = "gBSallaInfo";
            this.gBSallaInfo.Size = new System.Drawing.Size(547, 168);
            this.gBSallaInfo.TabIndex = 19;
            this.gBSallaInfo.TabStop = false;
            this.gBSallaInfo.Text = "Salle informatique :";
            // 
            // btnCryptageSalleI
            // 
            this.btnCryptageSalleI.BackgroundImage = global::AP1.Properties.Resources.secu;
            this.btnCryptageSalleI.Enabled = false;
            this.btnCryptageSalleI.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCryptageSalleI.ForeColor = System.Drawing.Color.Cyan;
            this.btnCryptageSalleI.Location = new System.Drawing.Point(360, 44);
            this.btnCryptageSalleI.Name = "btnCryptageSalleI";
            this.btnCryptageSalleI.Size = new System.Drawing.Size(150, 86);
            this.btnCryptageSalleI.TabIndex = 18;
            this.btnCryptageSalleI.Text = "Crypter le mot de passe";
            this.btnCryptageSalleI.UseVisualStyleBackColor = true;
            this.btnCryptageSalleI.Click += new System.EventHandler(this.btnCryptageSalleI_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tbEntB);
            this.groupBox1.Controls.Add(this.btnCryptageEntB);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.tbDigiB);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.ForeColor = System.Drawing.Color.Red;
            this.groupBox1.Location = new System.Drawing.Point(12, 115);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(541, 155);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Entrée du batiment :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 73);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(308, 20);
            this.label7.TabIndex = 19;
            this.label7.Text = "Veuillez saisir des mots de passe de 6 lettres :";
            // 
            // btnQuitter
            // 
            this.btnQuitter.BackColor = System.Drawing.Color.SteelBlue;
            this.btnQuitter.BackgroundImage = global::AP1.Properties.Resources.secu;
            this.btnQuitter.ForeColor = System.Drawing.Color.Cyan;
            this.btnQuitter.Location = new System.Drawing.Point(694, 12);
            this.btnQuitter.Name = "btnQuitter";
            this.btnQuitter.Size = new System.Drawing.Size(94, 29);
            this.btnQuitter.TabIndex = 21;
            this.btnQuitter.Text = "Quitter";
            this.btnQuitter.UseVisualStyleBackColor = false;
            this.btnQuitter.Click += new System.EventHandler(this.btnQuitter_Click);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.SteelBlue;
            this.btnReset.BackgroundImage = global::AP1.Properties.Resources.secu;
            this.btnReset.ForeColor = System.Drawing.Color.Cyan;
            this.btnReset.Location = new System.Drawing.Point(694, 453);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(94, 29);
            this.btnReset.TabIndex = 22;
            this.btnReset.Text = "Réinitialiser";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnRetour
            // 
            this.btnRetour.BackColor = System.Drawing.Color.SteelBlue;
            this.btnRetour.BackgroundImage = global::AP1.Properties.Resources.secu;
            this.btnRetour.ForeColor = System.Drawing.Color.Cyan;
            this.btnRetour.Location = new System.Drawing.Point(594, 453);
            this.btnRetour.Name = "btnRetour";
            this.btnRetour.Size = new System.Drawing.Size(94, 29);
            this.btnRetour.TabIndex = 23;
            this.btnRetour.Text = "Retour";
            this.btnRetour.UseVisualStyleBackColor = false;
            this.btnRetour.Click += new System.EventHandler(this.btnRetour_Click);
            // 
            // Cryptage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(800, 495);
            this.Controls.Add(this.btnRetour);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnQuitter);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gBSallaInfo);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Name = "Cryptage";
            this.Text = "Cryptage";
            this.Load += new System.EventHandler(this.Cryptage_Load);
            this.gBSallaInfo.ResumeLayout(false);
            this.gBSallaInfo.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbEntB;
        private System.Windows.Forms.TextBox tbDigiB;
        private System.Windows.Forms.TextBox tbSalleI;
        private System.Windows.Forms.TextBox tbDigiSI;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnCryptageEntB;
        private System.Windows.Forms.GroupBox gBSallaInfo;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnCryptageSalleI;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnQuitter;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnRetour;
    }
}