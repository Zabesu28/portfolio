﻿using System;
using System.IO;     //ajoute bibliothèque de commande
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AP1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn()    // si les deux zones de texte ne sont pas remplit, le bouton Connecter restera grisé. Si une des deux zones de texte est remplit, le bouton réinitialisé sera dégrisé.
        {
            if (tbMatricule.Text != "" || tbMdp.Text != "")
            {
                btnClear.Enabled = true;
                if (tbMatricule.Text != "" && tbMdp.Text != "")
                {
                    btnCo.Enabled = true;
                }
                else
                {
                    btnCo.Enabled = false;
                }
            }
            else
            {
                btnClear.Enabled = false;
            }
        }

        private void btnCo_Click(object sender, EventArgs e)
        {
            var reader = new StreamReader(File.OpenRead(@"../../../../../digicod_perso.csv")); // création d'une variable qui va ouvrir le fichier selectionné
            List<string> matricule = new List<string>();                                       // on défini une liste en lui donnant un nom
            while (!reader.EndOfStream)                                                        // tant que l'on est pas à la fin du tableau
            {
                var line = reader.ReadLine();          // variable qui va lire le tableau excel
                var values = line.Split(';');          // on passe d'une cellule à une autre en sautant les ; se trouvant entre les cellules.

                matricule.Add(values[0]);              // la colonne ou se trouve les valeurs recherchés (la colonne des matricules ici)
            }
            reader.Close();                            // ferme le fichier excel

            reader = new StreamReader(File.OpenRead(@"../../../../../digicod_secure.csv")); // création d'une variable qui va ouvrir le fichier selectionné
            List<string> Mdp = new List<string>();                                          // on défini une liste
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();         // variable qui va lire le tableau excel
                var values = line.Split(';');         // on passe d'une cellule à une autre en sautant les ; se trouvant entre les cellules.

                Mdp.Add(values[3]);                   // la colonne ou se trouve les valeurs recherchés (la colonne des mots de passe crypté ici)
            }
            reader.Close();                           // ferme le fichier excel

            if (tbMdp.Text == Mdp[7] && tbMatricule.Text == matricule[14])                  // Si les valeurs entrée ne correspondent pas au valeurs du tableau
            {
                MessageBox.Show("Vous allez être redirigé vers la page de cryptage.");      // Message d'alerte
                Cryptage f = new Cryptage();                                                // Donne un nom à la page que l'on va ouvrir
                f.Show();                                                                   // Ouvre la page
                this.Hide();                                                                // ferme la page précédente
            }
            else
            {
                MessageBox.Show("Erreur, veillez ressaisir les identifiants");              // Message d'alerte
                tbMatricule.Clear();                                                        // vide la zone de texte
                tbMdp.Clear();                                                              // vide la zone de texte
            }
        } // bouton permettant de se connecter à la page de cryptage si les identifiants sont correct

        private void btnQuitter_Click(object sender, EventArgs e)
        {
            Application.Exit();                                                             // ferme le programme
        } // bouton permettant de fermer le programme

        private void tbMatricule_TextChanged(object sender, EventArgs e)
        {
            btn();                                                                          // fonction qui grise le bouton quand il faut
        } // gère le grisage du bouton

        private void tbMdp_TextChanged(object sender, EventArgs e)
        {
            btn();                                                                          // fonction qui grise le bouton quand il faut
        } // gère le grisage du bouton

        private void btnClear_Click(object sender, EventArgs e)
        {
            tbMatricule.Clear();                                                           // vide la zone de texte
            tbMdp.Clear();                                                                 // vide la zone de texte
        } // bouton permettant de réinitialiser les textbox 


    }
}
